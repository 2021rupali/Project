import { BrowserRouter as Router, Routes,Route } from "react-router-dom";

import "./components/assets/css/animate.min.css";
import "./components/assets/css/magnific-popup.css";
import "./components/assets/css/flaticon.css";
import "./components/assets/css/odometer.css";
import "./components/assets/css/aos.css";
import "./components/assets/css/slick.css";
import "./components/assets/css/default.css";
import "./components/assets/css/style.css";
import "./components/assets/css/responsive.css";
import MainHeadre from "./components/layout/header/MainHeadre";
import TopHeader from "./components/layout/header/TopHeader";
import MainFooter from "./components/layout/footer/MainFooter";
import BottomFooter from "./components/layout/footer/BottomFooter";
import Home from "./components/pages/home/Home";
import Home2 from "./components/pages/home/Home2";
import Home3 from "./components/pages/home/Home3";
import Company from "./components/pages/company/Company";
import OurServies from "./components/pages/services/OurServies";
import ServicesDetails from "./components/pages/services/ServicesDetails";
import OurBlog from "./components/pages/news/OurBlog";
import BlogDetails from "./components/pages/news/BlogDetails";
import Contacts from "./components/pages/contacts/Contacts";

function App() {
  return (
    <>
<Router>
      <header>
        <TopHeader />
        <MainHeadre />
      </header>

  <Routes>
    <Route path="/" element={<Home />} />
    <Route path="/software" element={<Home2 />} />
    <Route path="/consulting" element={<Home3 />} />
    <Route path="/company" element={<Company />} />
    <Route path="/OurServies" element={<OurServies />} />
    <Route path="/ServicesDetails" element={<ServicesDetails />} />
    <Route path="/OurBlog" element={<OurBlog />} />
    <Route path="/BlogDetails" element={<BlogDetails />} />
    <Route path="/Contacts" element={<Contacts />} />
    {/* <Route path="*" element={<Home />} /> */}
  </Routes>

  <footer>
        <MainFooter />
        <BottomFooter />
      </footer>
</Router>
      
    </>
  );
}

export default App;
