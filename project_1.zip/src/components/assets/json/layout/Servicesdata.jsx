export const Servicesdata=[
    {
        Our_Services:[
            {img:'img/images/delivering_value01.jpg', path:'/ServicesDetails',title:'Analysis Techniques', icon1:'flaticon-bar-chart', icon2:'fas fa-caret-right' ,info:'Making beauty especially relating complexion especially.', button:'Read more'},
    {img:'img/images/delivering_value02.jpg', path:'/ServicesDetails',title:'Cloud Computing', icon1:'flaticon-lamp', icon2:'fas fa-caret-right' ,info:'Making beauty especially relating complexion especially.', button:'Read more'},
    {img:'img/images/delivering_value03.jpg', path:'/ServicesDetails',title:'Connect Easily', icon1:'flaticon-maintenance', icon2:'fas fa-caret-right' ,info:'Making beauty especially relating complexion especially.', button:'Read more'}
        ]
    }
]