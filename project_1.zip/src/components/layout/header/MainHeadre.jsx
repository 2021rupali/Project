import React from 'react'
import logo from '../../assets/img/logo/logo.png'
import {NavLink} from 'react-router-dom'
import { AllinOne } from '../../assets/json/layout/AllinOne'
function MainHeadre() {
  return (
    <>
        <div id="sticky-header" className="main-header menu-area">
                <div className="container custom-container">
                    <div className="row">
                        <div className="col-12">
                            <div className="mobile-nav-toggler"><i className="fas fa-bars"></i></div>
                            <div className="menu-wrap">
                                <nav className="menu-nav show">
                                    <div className="logo">
                                        <NavLink to={'/'}><img src={logo} alt=""/></NavLink>
                                    </div>
                                    <div className="navbar-wrap main-menu d-none d-lg-flex">
                                        <ul className="navigation">
                                            {
                                                AllinOne.map((data)=>{
                                                    return(
                                                        data.Header.map((mainData)=>{
                                                            return(
                                                                <li className={mainData.dropdown==='yes'? "menu-item-has-children" : ""}><NavLink to={mainData.path}>{mainData.title}</NavLink>
                                                           {
                                                               mainData.dropdown==='yes'&&
                                                               <ul className="submenu">
                                                            {
                                                                mainData.data.map((SubData)=>{
                                                                   return(
                                                                       <li><NavLink to={SubData.path}>{SubData.name}</NavLink></li>
                                                                   )
                                                                })
                                                              }
                                                        </ul>
                                                           }
                                                           
                                                    </li>
                                                            )
                                                        })
                                                    )
                                                })
                                            }
                                        </ul>
                                    </div>
                                    <div className="header-action d-none d-md-block">
                                        <ul>
                                            <li className="header-search"><NavLink to={'/'}><i className="flaticon-search-magnifier-outline"></i></NavLink></li>
                                            <li className="header-btn"><NavLink to={'/'} className="btn">Get A Quote <span></span></NavLink></li>
                                        </ul>
                                    </div>
                                </nav>
                            </div>
            
                            <div className="mobile-menu">
                                <nav className="menu-box">
                                    <div className="close-btn"><i className="fas fa-times"></i></div>
                                    <div className="nav-logo"><NavLink to={'/'}><img src={logo} alt="" title=""/></NavLink>
                                    </div>
                                    <div className="menu-outer">
                                    </div>
                                    <div className="social-links">
                                        <ul className="clearfix">
                                            <li><a href="#"><span className="fab fa-twitter"></span></a></li>
                                            <li><a href="#"><span className="fab fa-facebook-square"></span></a></li>
                                            <li><a href="#"><span className="fab fa-pinterest-p"></span></a></li>
                                            <li><a href="#"><span className="fab fa-instagram"></span></a></li>
                                            <li><a href="#"><span className="fab fa-youtube"></span></a></li>
                                        </ul>
                                    </div>
                                </nav>
                            </div>
                            <div className="menu-backdrop"></div>
                        </div>
                    </div>
                </div>
            </div>
    </>
  )
}

export default MainHeadre