import React from "react";
import { NavLink } from "react-router-dom";
import { AllinOne } from "../assets/json/layout/AllinOne";
function ServiceArea() {
  return (
    <>
      <section className="kb-services-area">
        <div className="container">
          <div className="">
            <div className="row justify-content-center">
              <div className="col-xl-6 col-lg-8">
                <div className="kb-section-title text-center mb-55">
                  <h2 className="title">Choose Your Support Online</h2>
                  <p>
                    Get the latest Services and breaking news from Worald around
                    the globe news
                  </p>
                </div>
              </div>
            </div>
            <div className="row justify-content-center">
              {
                AllinOne.map((data)=>{
                  return(
                    data.Service.map((data) => {
                      return (
                        <div className="col-xl-4 col-lg-4 col-md-6 col-sm-10">
                          <div className="kb-services-item">
                            <NavLink
                              to={data.path}
                              className="kb-services-link"
                            ></NavLink>
                            <div className="icon">
                              <i className={data.icon}></i>
                            </div>
                            <div className="content">
                              <h5>
                                {data.type}
                                <span className={data.stamp === "NEW" ? "new" : ""}>
                                  {data.stamp}
                                </span>
                              </h5>
                              <p>{data.details}</p>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )
                })
              }
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default ServiceArea;
