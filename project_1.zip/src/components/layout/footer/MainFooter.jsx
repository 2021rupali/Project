// import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import { AllinOne } from "../../assets/json/layout/AllinOne";
function MainFooter() {
  // useEffect(() => {
  //   console.log("FooterMenu", Footer);
  // }, []);
  return (
    <>
      <div className="footer-top-wrap gray-bg">
        <div className="container">
          <div className="container-inner-wrap">
            <div className="row">
              {
                AllinOne.map((data)=>{
                  return(
                    data.Footer.map((item) => {
                      return (
                        <div className="col">
                          <div className="footer-widget ">
                            <div className="fw-title">
                              <h5 className="title">{item.title}</h5>
                            </div>
                            <div
                              className={
                                item.type === "link" ? "fw-link" : "fw-social"
                              }
                            >
                              {item.type === "link" && (
                                <ul>
                                  {item.list.map((data) => {
                                    return (
                                      <li>
                                        <Link to={data.path}>{data.name}</Link>
                                      </li>
                                    );
                                  })}
                                </ul>
                              )}
                              {item.type === "icon" && (
                                <ul>
                                  {item.list.map((data) => {
                                    return (
                                      <li>
                                        <Link to={data.path}>
                                          <i className={data.name}></i>
                                        </Link>
                                      </li>
                                    );
                                  })}
                                </ul>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )
                })
              }
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default MainFooter;
