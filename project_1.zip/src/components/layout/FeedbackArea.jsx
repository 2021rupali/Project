import React from "react";
import { Link } from "react-router-dom";
import { AllinOne } from "../assets/json/layout/AllinOne";

function FeedbackArea() {
  return (
    <>
        <div className="container">
          <div className="">
            <div className="row">
              <div className="col-12">
                <div className="customer-feedback-title">
                  <h2 className="title">How our customers use Artom</h2>
                  <div className="feedback-slider-nav"></div>
                </div>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-12">
              <div className="customer-feedback-active">
                {
                  AllinOne.map((data)=>{
                    return(
                      data.Feedback.map((data) => {
                        return (
                          <div className="customer-feedback-item">
                            <div className="feedback-item-content">
                              <div className="feedback-tags">
                                <ul>
                                  {data.tag.map((list) => {
                                    return (
                                      <li className={list.type === "active" ? "active" : ""}>
                                        <Link to={list.path}>{list.name}</Link>
                                      </li>
                                    );
                                  })}
                                </ul>
                              </div>
                              <h2 className="title">{data.title}</h2>
                              <div className="feedback-client">
                                <div className="thumb">
                                  <img src={data.img_link} alt="" />
                                </div>
                                <div className="info">
                                  {data.infos.map((info) => {
                                    return (
                                      <>
                                        <h5>{info.devloper}</h5>
                                        <span>{info.skills}</span>
                                      </>
                                    );
                                  })}
                                </div>
                              </div>
                              <Link to={"#"} className="btn feedback-btn">
                                {data.text_button}
                              </Link>
                            </div>
                            <div
                              className="feedback-img"
                              style={{ backgroundImage: `url(${data.bg_link})` }}
                            ></div>
                          </div>
                        );
                      })
                    )
                  })
                }
              </div>
            </div>
          </div>
        </div>
    </>
  );
}

export default FeedbackArea;
