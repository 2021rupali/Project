import React from "react";
import { Link } from "react-router-dom";
import { AllinOne } from "../assets/json/layout/AllinOne";

function TeamArea() {
  return (
    <>
      <div className="container">
        <div className="">
          <div className="row justify-content-center">
            <div className="col-xl-6 col-lg-8">
              <div className="kb-section-title text-center white-title mb-55">
                <h2 className="title">
                  Our Happy Team Members<span>.</span>
                </h2>
                <p>
                  Get the latest Services and breaking news from Worald around
                  the globe news
                </p>
              </div>
            </div>
          </div>
          <div className="row justify-content-center">
            {
              AllinOne.map((data)=>{
                return(
                  data.Team.map((data) => {
                    return (
                      <div className="col-xl-3 col-lg-4 col-sm-6">
                        <div className="team-item">
                          <div className="team-thumb">
                            <img src={data.img_link} alt="" />
                            <span className="thumb-bg"></span>
                          </div>
                          <div className="team-content">
                            <span>{data.info.profession}</span>
                            <h5>
                              <Link to={"#"}>{data.info.name}</Link>
                            </h5>
                            <p>
                              Making for beauty the especially relating complexion.
                            </p>
                          </div>
                        </div>
                      </div>
                    );
                  })
                )
              })
            }
          </div>
        </div>
      </div>
    </>
  );
}

export default TeamArea;
