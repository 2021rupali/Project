import React from 'react'
import { NavLink} from 'react-router-dom'

import bg1 from '../../assets/img/bg/breadcrumb_bg.jpg'
import bg2 from '../../assets/img/bg/feedback_bg.jpg'
import bg6 from '../../assets/img/bg/team_bg.jpg'

import FeedbackArea from '../../layout/FeedbackArea'
import TeamArea from '../../layout/TeamArea'
import ServiceArea from '../../layout/ServiceArea'
import TrialArea from '../../layout/TrialArea'
import SupportArea from '../../layout/SupportArea'

function Company() {
  return (
    <div>

<section className="breadcrumb-area breadcrumb-bg" style={{ backgroundImage: `url(${bg1})` }} >
    <div className="container">
        <div className="">
            <div className="row">
                <div className="col-12">
                    <div className="breadcrumb-content">
                        <h2 className="title">Company</h2>
                        <nav aria-label="breadcrumb">
                            <ol className="breadcrumb">
                                <li className="breadcrumb-item"><NavLink to={'/'}>Home</NavLink></li>
                                <li className="breadcrumb-item active" aria-current="page">Company</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section className="customer-feedback-area" style={{ backgroundImage: `url(${bg2})` }}>
<FeedbackArea/>
</section>

<section className="team-area team-bg" style={{ backgroundImage: `url(${bg6})` }} >
    <TeamArea/>
</section>

<ServiceArea/>

<TrialArea/>

<SupportArea/>

    </div>
  )
}

export default Company