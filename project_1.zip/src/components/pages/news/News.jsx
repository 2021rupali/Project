import React from "react";
import { Link, NavLink } from "react-router-dom";
import { Newsdata } from "../../assets/json/layout/Newsdata";

function News() {
  return (
    <>
      <div className="col-lg-4 col-md-10">
        <aside className="blog-sidebar">
          <div className="widget">
            <h4 className="widget-title">Search</h4>
            <div className="sidebar-search-form">
              <form action="#">
                <input type="text" placeholder="Search ..." />
              </form>
            </div>
          </div>
          <div className="widget">
            <h4 className="widget-title">Recent Posts</h4>
            <div className="rc-post-list">
              <ul>
                {
                  Newsdata.map((data)=>{
                    return(
                      data.Side_menu.map((data) => {
                        return data.posts.map((post) => {
                          return (
                            <li>
                              <div className="rc-post-thumb">
                                <NavLink to={post.path}>
                                  <img src={post.img} alt="" />
                                </NavLink>
                              </div>
                              <div className="rc-post-content">
                                <h6 className="title">
                                  <NavLink to={post.path}>{post.title}</NavLink>
                                </h6>
                                <span className="date">
                                  <i className={post.icon}></i>
                                  {post.date}
                                </span>
                              </div>
                            </li>
                          );
                        });
                      })
                    )
                  })
                }
              </ul>
            </div>
          </div>
          <div className="widget">
            <h4 className="widget-title">Categories</h4>
            <div className="sidebar-cat-list">
              <ul>
                {
                    Newsdata.map((data)=>{
                      return(
                        data.Side_menu.map((data)=>{
                          return(
                              data.Categories.map((categorie)=>{
                                  return(
                                      <li><Link to={categorie.path}>{categorie.type}<i className={categorie.icon}></i></Link></li>
                                  )
                              })
                          )
                      })
                      )
                    })
                }
              </ul>
            </div>
          </div>
          <div className="widget">
            <div className="sidebar-add">
              {
               Newsdata.map((data)=>
               {
                return(
                  data.Side_menu.map((data)=>{
                    return(
                        data.sidebar.map((item)=>{
                            return(
                                <Link to={item.path}> <img src={item.img} alt="" /> </Link>
                            )
                        })
                    )
                })
                )
               })
              }
            </div>
          </div>
          <div className="widget">
            <h4 className="widget-title">Tag Cloud</h4>
            <div className="sidebar-tag-list">
              <ul>
                {
                   Newsdata.map((data)=>{
                    return(
                      data.Side_menu.map((data)=>{
                        return(
                            data.tags.map((tag)=>{
                                return(
                                    <li> <Link to={tag.path}>{tag.tag}</Link> </li>
                                )
                            })
                        )
                    })
                    )
                   })
                }
              </ul>
            </div>
          </div>
        </aside>
      </div>
    </>
  );
}

export default News;
