import React from 'react'
import {Link, NavLink} from 'react-router-dom'
import { Newsdata } from '../../assets/json/layout/Newsdata'
import bg1 from '../../assets/img/bg/breadcrumb_bg.jpg'
import News  from './News'

function OurBlog() {
  return (
    <>
<section className="breadcrumb-area breadcrumb-bg" style={{ backgroundImage: `url(${bg1})` }} >
    <div className="container">
        <div className="">
            <div className="row">
                <div className="col-12">
                    <div className="breadcrumb-content">
                        <h2 className="title">Latest News Update</h2>
                        <nav aria-label="breadcrumb">
                            <ol className="breadcrumb">
                                <li className="breadcrumb-item"><NavLink to={'/'}>Home</NavLink></li>
                                <li className="breadcrumb-item active" aria-current="page">BLOG Right SIDEBAR</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section className="blog-area blog-gray-bg">
    <div className="container">
        <div className="">
            <div className="row justify-content-center">

                <div className="col-lg-8 col-md-10">
{
    Newsdata.map((data)=>{
        return(
            data.Our_Blog.map((data)=>{
                return(
                    <div className="standard-blog-item mb-50">
                                <div className="blog-thumb">
                                    <NavLink to={data.path}><img src={data.img}  alt=""/></NavLink>
                                </div>
                                <div className="standard-blog-content">
                                    <h4 className="title"><NavLink to={data.path}>{data.title}</NavLink></h4>
                                    <ul className="standard-blog-meta">
                                        <li><Link to={'#'}><i className={data.icon1}></i>{data.name}</Link></li>
                                        <li><Link to={'#'}><i className={data.icon2}></i>{data.date}</Link></li>
                                        <li><Link to={'#'}><i className={data.icon3}></i>{data.Comments}</Link></li>
                                    </ul>
                                    <p>{data.containt}</p>
                                    <div className="blog-line" style={{ backgroundImage: `url(${data.bg_img})` }} ></div>
                                    <NavLink to={data.path} className="btn read-more">{data.button}</NavLink>
                                </div>
                            </div>
                )
            })
        )
    })
}
                </div>
                <News/>
            </div>
        </div>
    </div>
</section>

    </>
  )
}

export default OurBlog