import React from 'react'
import {Link, NavLink} from 'react-router-dom'

import bg1 from '../../assets/img/bg/breadcrumb_bg.jpg'
import bg2 from '../../assets/img/blog/blog_item_line.png'

import img1 from '../../assets/img/blog/blog_thumb01.jpg'
import img2 from '../../assets/img/blog/blog_details_img01.jpg'
import img3 from '../../assets/img/blog/blog_details_img02.jpg'
import img4 from '../../assets/img/blog/post_avatar_img.png'
import img5 from '../../assets/img/icon/left_arrow.png'
import img6 from '../../assets/img/icon/right_arrow.png'
import img7 from '../../assets/img/blog/rc_post_thumb01.jpg'
import img8 from '../../assets/img/blog/rc_post_thumb02.jpg'
import img9 from '../../assets/img/blog/rc_post_thumb03.jpg'
import img10 from '../../assets/img/blog/add.png'


function BlogDetails() {
  return (
    <>
         
<section class="breadcrumb-area breadcrumb-bg" style={{ backgroundImage: `url(${bg1})` }}>
    <div class="container">
        <div class="">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb-content">
                        <h2 class="title">News Details</h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><NavLink to={'/'}>Home</NavLink></li>
                                <li class="breadcrumb-item active" aria-current="page">BLOG single</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="blog-details-area blog-gray-bg">
    <div class="container">
        <div class="">
            <div class="row justify-content-center">
                <div class="col-lg-8 col-md-10">
                    <div class="standard-blog-item mb-50">
                        <div class="blog-thumb">
                            <img src={img1}  alt=""/>
                        </div>
                        <div class="standard-blog-content blog-details-content">
                            <h4 class="title">Providing Professional or Expert Advice</h4>
                            <ul class="standard-blog-meta">
                                <li><Link to={'#'}><i class="far fa-user"></i>By Tome</Link></li>
                                <li><Link to={'#'}><i class="far fa-calendar"></i>April 15, 2021</Link></li>
                                <li><Link to={'#'}><i class="far fa-comment-alt"></i>0 Comments</Link></li>
                            </ul>
                            <p>Consulting is defined as the practise of providing a third party with etise on matter in exchange for a fee. The service
                            may involve either advisory or implementation services. For the consultant, taking an independen center with a caption,
                            link and alt text New Journey to the Mars in the Gutenberg editor, you can drag and drop an image from your computer
                            onto the editing screen.</p>
                            <p>Design comes alive – an app becomes an interactive story that can engage users. Designers have a lot of tools to make a
                            story more interesting. You can align your image to the left, right, or center with a caption, link and alt text New
                            Journey to the Mars in the Gutenberg editor.</p>
                            <blockquote>
                                “ Consulting is defined the practise of providing is third party with expertise on a matters in exchange a free
                                advisory or implementation services ”
                                <footer>Rosalina D.William</footer>
                            </blockquote>
                            <p>Becomes an interactive story that can engage users. Designers have a lot of tools to make a story more intersting. You
                            can align your image to the leftcenter with a caption, link and alt text New Journey to the Marstaking.</p>
                            <div class="blog-details-list">
                                <ul>
                                    <li><Link to={'#'}>Marketing consulting Online Business</Link> – an app becomes ans interactive story that can engage users. Designers have tools to make</li>
                                    <li><Link to={'#'}>Design comes ecomes an interactive alive</Link> – Business becomes ans interactive story that can engage users.</li>
                                </ul>
                            </div>
                            <div class="blog-details-img">
                                <div class="row">
                                    <div class="col-md-6">
                                        <img src={img2}  alt=""/>
                                    </div>
                                    <div class="col-md-6">
                                        <img src={img3} alt=""/>
                                    </div>
                                </div>
                            </div>
                            <p>Becomes an interactive story that can engage users. Designers have a lot of tools to make a story more intersting. You
                            can align your image to the leftcenter with a caption, link and alt text New Journey to the Marstaking an independen
                            center with a caption, link and alt text New Journey to the Mars.</p>
                            <div class="blog-line" style={{ backgroundImage: `url(${bg2})` }}></div>
                            <div class="blog-details-bottom">
                                <div class="blog-details-tags">
                                    <ul>
                                        <li class="title"><i class="fas fa-tags"></i> Tags :</li>
                                        <li><Link to={'#'}>Business</Link></li>
                                        <li><Link to={'#'}>Work</Link></li>
                                        <li><Link to={'#'}>Knowledge</Link></li>
                                        <li><Link to={'#'}>Online</Link></li>
                                    </ul>
                                </div>
                                <div class="blog-details-social">
                                    <ul>
                                        <li><Link to={'#'}><i class="fab fa-facebook-f"></i></Link></li>
                                        <li><Link to={'#'}><i class="fab fa-twitter"></i></Link></li>
                                        <li><Link to={'#'}><i class="fab fa-linkedin-in"></i></Link></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="avatar-post mt-50 mb-50">
                        <div class="post-avatar-img">
                            <img src={img4} alt="img"/>
                        </div>
                        <div class="post-avatar-content">
                            <h5>Thomas Herlihy</h5>
                            <p>Becomes interve story that can engage users. Designers have ools to make a story more intersting.</p>
                            <div class="blog-details-social">
                                <ul>
                                    <li><Link to={'#'}><i class="fab fa-facebook-f"></i></Link></li>
                                    <li><Link to={'#'}><i class="fab fa-twitter"></i></Link></li>
                                    <li><Link to={'#'}><i class="fab fa-linkedin-in"></i></Link></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="blog-next-prev">
                        <ul>
                            <li class="blog-prev">
                                <Link to={'#'}><img src={img5} alt="img"/>Previous Post</Link>
                            </li>
                            <li class="blog-next">
                                <Link to={'#'}>Next Post<img src={img6} alt="img"/></Link>
                            </li>
                        </ul>
                    </div>
                    <div class="comment-reply-box">
                        <h5 class="title">LEAVE A REPLY</h5>
                        <form action="#" class="comment-reply-form">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-grp">
                                        <input type="text" placeholder="Author *"/>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-grp">
                                        <input type="email" placeholder="Your Email *"/>
                                    </div>
                                </div>
                            </div>
                            <div class="form-grp">
                                <textarea name="message" placeholder="Type Comment Here..."></textarea>
                            </div>
                            <div class="form-grp checkbox-grp">
                                <input type="checkbox" id="checkbox"/>
                                <label for="checkbox">Don’t show your email address</label>
                            </div>
                            <button type="submit" class="btn">Submit now</button>
                        </form>
                    </div>
                </div>
                <div class="col-lg-4 col-md-10">
                    <aside class="blog-sidebar">
                        <div class="widget">
                            <h4 class="widget-title">Search</h4>
                            <div class="sidebar-search-form">
                                <form action="#">
                                    <input type="text" placeholder="Search ..."/>
                                </form>
                            </div>
                        </div>
                        <div class="widget">
                            <h4 class="widget-title">Recent Posts</h4>
                            <div class="rc-post-list">
                                <ul>
                                    <li>
                                        <div class="rc-post-thumb">
                                            <NavLink to={'/BlogDetails'}><img src={img7} alt=""/></NavLink>
                                        </div>
                                        <div class="rc-post-content">
                                            <h6 class="title"><NavLink to={'/BlogDetails'}>How Manage Business’s Online Reputation</NavLink></h6>
                                            <span class="date"><i class="far fa-calendar-alt"></i> August 19, 2021</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="rc-post-thumb">
                                            <NavLink to={'/BlogDetails'}><img src={img8} alt=""/></NavLink>
                                        </div>
                                        <div class="rc-post-content">
                                            <h6 class="title"><NavLink to={'/BlogDetails'}>Consulting is defined as the practise</NavLink></h6>
                                            <span class="date"><i class="far fa-calendar-alt"></i> August 19, 2021</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="rc-post-thumb">
                                            <NavLink to={'/BlogDetails'}><img src={img9} alt=""/></NavLink>
                                        </div>
                                        <div class="rc-post-content">
                                            <h6 class="title"><NavLink to={'/BlogDetails'}>Marketing consulting Online Business</NavLink></h6>
                                            <span class="date"><i class="far fa-calendar-alt"></i> August 19, 2021</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="widget">
                            <h4 class="widget-title">Categories</h4>
                            <div class="sidebar-cat-list">
                                <ul>
                                    <li><NavLink to={'/consulting'}>Consultancy Service? <i class="fas fa-angle-double-right"></i></NavLink></li>
                                    <li><NavLink to={'/'}>Knowledge Base <i class="fas fa-angle-double-right"></i></NavLink></li>
                                    <li><Link to={'#'}>Online Business <i class="fas fa-angle-double-right"></i></Link></li>
                                    <li><Link to={'#'}>Remote Work <i class="fas fa-angle-double-right"></i></Link></li>
                                </ul>
                            </div>
                        </div>
                        <div class="widget">
                            <div class="sidebar-add">
                                <Link to={'#'}><img src={img10} alt=""/></Link>
                            </div>
                        </div>
                        <div class="widget">
                            <h4 class="widget-title">Tag Cloud</h4>
                            <div class="sidebar-tag-list">
                                <ul>
                                    <li><Link to={'#'}># Business</Link></li>
                                    <li><Link to={'#'}># Knowledge</Link></li>
                                    <li><Link to={'#'}># Work</Link></li>
                                    <li><Link to={'#'}># Online</Link></li>
                                    <li><Link to={'#'}># Who</Link></li>
                                    <li><Link to={'#'}># Technology</Link></li>
                                    <li><Link to={'#'}># Consult</Link></li>
                                </ul>
                            </div>
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </div>
</section>

    </>
  )
}

export default BlogDetails