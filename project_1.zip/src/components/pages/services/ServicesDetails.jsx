import React from 'react'
import {Link, NavLink} from 'react-router-dom'

import bg1 from '../../assets/img/bg/breadcrumb_bg.jpg'

import img1 from '../../assets/img/images/services_details_img01.jpg'
import img2 from '../../assets/img/images/services_details_img02.jpg'
import img3 from '../../assets/img/images/services_details_img03.jpg'

import TrialArea from '../../layout/TrialArea'

function ServicesDetails() {
  return (
    <>


<section className="breadcrumb-area breadcrumb-bg" style={{ backgroundImage: `url(${bg1})` }}>
    <div className="container">
        <div className="">
            <div className="row">
                <div className="col-12">
                    <div className="breadcrumb-content">
                        <h2 className="title">Our Service Details</h2>
                        <nav aria-label="breadcrumb">
                            <ol className="breadcrumb">
                                <li className="breadcrumb-item"><NavLink to={'/'}>Home</NavLink></li>
                                <li className="breadcrumb-item active" aria-current="page">Details</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section className="services-details-area">
    <div className="container">
        <div className="">
            <div className="row">
                <div className="col-12">
                    <div className="services-details-img">
                        <img src={img1}  alt=""/>
                    </div>
                    <div className="services-details-content">
                        <div className="sd-tags-wrap">
                            <ul>
                                <li><Link to={'#'}>articles</Link></li>
                            </ul>
                        </div>
                        <h2 className="title">Providing Professional or Expert Advice</h2>
                        <p>Design comes alive – an app becomes an interactive story that can engage users. Desiers have a lot of tools to make a
                        story more interesting. You can align your image to the left, right, or center with a caption, link and altext New
                        Journey to in the Guerg edigtor. taking an independen center with a caption, link and alt text New Journey to the Mars
                        in the Today, the term Information Technol has ballooned to encompass many aspects of computing and technology and the
                        term is more recognizable than ever before. The Information Technology umbrella can be quite large, covering many
                        fields. IT profeals perform a variety of duties that range from installing applications, managing information, to
                        designing complex applications, managing computer networks and designing and managing databases.</p>
                        <div className="blog-details-list">
                            <ul>
                                <li><Link to={'#'}>Marketing consulting Online Business</Link> – an app becomes ans interactive story that can engage users. Designers have tools to make ink and altext New Journey to the Mars</li>
                                <li><Link to={'#'}>Design comes e-comes an interactive alive</Link> – Business becomes ans interactive story that can engage users.</li>
                            </ul>
                        </div>
                        <div className="sd-images-wrap">
                            <div className="row">
                                <div className="col-md-6">
                                    <img src={img2}  alt=""/>
                                </div>
                                <div className="col-md-6">
                                    <img src={img3}  alt=""/>
                                </div>
                            </div>
                        </div>
                        <h4 className="title">How it Works?</h4>
                        <p>Design comes alive – an app becomes an interactive story that can engage users. Desiers have a lot of tools to make a
                        story more interesting. You can align your image to the left, right, or center with a caption, link and altext New
                        Journey to in the Guerg edigtor. taking an independen center with a caption, link and alt text New Journey to the Mars
                        in the Today, the term Information Technol has ballooned to encompass many aspects of computing and technology and the
                        term is more recognizable than ever before.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<TrialArea/>

    </>
  )
}

export default ServicesDetails