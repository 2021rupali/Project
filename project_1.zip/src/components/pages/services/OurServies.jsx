import React from 'react'
import { NavLink} from 'react-router-dom'
import { Servicesdata } from '../../assets/json/layout/Servicesdata'

import bg1 from '../../assets/img/bg/breadcrumb_bg.jpg'
import bg2 from '../../assets/img/bg/feedback_bg.jpg'
import img9 from '../../assets/img/images/faq_img.jpg'
import img10 from '../../assets/img/images/faq_img_shape02.png'
import FeedbackArea from '../../layout/FeedbackArea'
import ServiceArea from '../../layout/ServiceArea'
import TrialArea from '../../layout/TrialArea'


function OurServies() {
  return (
    <>
        <main>


<section className="breadcrumb-area breadcrumb-bg" style={{ backgroundImage: `url(${bg1})` }} >
    <div className="container">
        <div className="">
            <div className="row">
                <div className="col-12">
                    <div className="breadcrumb-content">
                        <h2 className="title">Our Service</h2>
                        <nav aria-label="breadcrumb">
                            <ol className="breadcrumb">
                                <li className="breadcrumb-item"><NavLink to={'/'}>Home</NavLink></li>
                                <li className="breadcrumb-item active" aria-current="page">Service</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section className="delivering-value-area pt-110 pb-70">
    <div className="container">
        <div className="">
            <div className="row justify-content-center">
                <div className="col-xl-6 col-lg-8">
                    <div className="kb-section-title text-center mb-55">
                        <h2 className="title">Delivering Value Customers.</h2>
                        <p>Get the latest Services and breaking news from Worald around the globe news</p>
                    </div>
                </div>
            </div>
            <div className="row justify-content-center">
{
    Servicesdata.map((data)=>{
        return(
                    data.Our_Services.map((data)=>{
                        return(
                            <div className="col-xl-4 col-lg-5 col-md-6 col-sm-10">
                            <div className="delivering-value-item">
                                <div className="dv-thumb">
                                    <NavLink to={data.path}><img src={data.img} alt=""/></NavLink>
                                </div>
                                <div className="dv-content-wrap">
                                    <div className="icon"><i className={data.icon1}></i></div>
                                    <div className="content">
                                        <h4 className="title"><NavLink to={data.path}>{data.title}</NavLink></h4>
                                        <p>{data.info}</p>
                                        <NavLink to={data.path}>Read more <i className={data.icon2}></i></NavLink>
                                    </div>
                                </div>
                            </div>
                        </div>
                        )
                    })
        )
    })
}
            </div>
        </div>
    </div>
</section>

<section className="customer-feedback-area" style={{ backgroundImage: `url(${bg2})` }} >
    <FeedbackArea/>
</section>

<ServiceArea/>

<TrialArea/>

<section className="faq-area pt-120 pb-120">
    <div className="container">
        <div className="">
            <div className="row">
                <div className="col-lg-6">
                    <div className="faq-img">
                        <img src={img9} alt=""/>
                        <img src={img10} alt="" className="faq-bottom-sh/ape"/>
                    </div>
                </div>
                <div className="col-lg-6">
                    <div className="section-title-two">
                        <h5 className="sub-title">FAQ</h5>
                        <h2 className="title">Frequently Asked Questions<span>.</span></h2>
                    </div>
                    <div className="faq-search-form">
                        <form action="#">
                            <input type="text" placeholder="Find What you need..."/>
                            <button className="btn">Search</button>
                        </form>
                    </div>
                    <ul className="nav nav-tabs faq-nav-tabs" id="myTab" role="tablist">
                        <li className="nav-item" role="presentation">
                            <a className="nav-link active" id="soft-tab" data-toggle="tab" href="#soft" role="tab" aria-controls="soft" aria-selected="true">
                                <i className="flaticon-copy"></i>
                                <span className="heading">Software</span>
                                <span className="desc">Upcoming Project</span>
                            </a>
                        </li>
                        <li className="nav-item" role="presentation">
                            <a className="nav-link" id="upcoming-tab" data-toggle="tab" href="#upcoming" role="tab" aria-controls="upcoming" aria-selected="false">
                                <i className="flaticon-copy"></i>
                                <span className="heading">upcoming</span>
                                <span className="desc">Upcoming Project</span>
                            </a>
                        </li>
                        <li className="nav-item" role="presentation">
                            <a className="nav-link" id="know-tab" data-toggle="tab" href="#know" role="tab" aria-controls="know" aria-selected="false">
                                <i className="flaticon-copy"></i>
                                <span className="heading">Know About</span>
                                <span className="desc">Upcoming Project</span>
                            </a>
                        </li>
                    </ul>
                    <div className="tab-content faq-tab-content" id="myTabContent">
                        <div className="tab-pane fade show active" id="soft" role="tabpanel" aria-labelledby="soft-tab">
                            <div className="accordion faq-wrapper" id="accordionExample">
                                <div className="card">
                                    <div className="card-header" id="headingOne">
                                        <h2 className="mb-0">
                                            <button className="btn-link" type="button" data-toggle="collapse"
                                                data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                               <span className="count">1.</span> Frequently asked questions forum is often used ?
                                            </button>
                                        </h2>
                                    </div>
                                    <div id="collapseOne" className="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                                        <div className="card-body">
                                            Making beauty especally relating complon especi common questions tend to recur, for example through posts or queries.
                                        </div>
                                    </div>
                                </div>
                                <div className="card">
                                    <div className="card-header" id="headingTwo">
                                        <h2 className="mb-0">
                                            <button className="btn-link collapsed" type="button" data-toggle="collapse"
                                                data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                <span className="count">2.</span> Business is shared to clarify questions ?
                                            </button>
                                        </h2>
                                    </div>
                                    <div id="collapseTwo" className="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                                        <div className="card-body">
                                            Making beauty especally relating complon especi common questions tend to recur, for example through posts or queries.
                                        </div>
                                    </div>
                                </div>
                                <div className="card">
                                    <div className="card-header" id="headingThree">
                                        <h2 className="mb-0">
                                            <button className="btn-link collapsed" type="button" data-toggle="collapse"
                                                data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                <span className="count">3.</span> Making beauty especally relating complon especi ?
                                            </button>
                                        </h2>
                                    </div>
                                    <div id="collapseThree" className="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                                        <div className="card-body">
                                            Making beauty especally relating complon especi common questions tend to recur, for example through posts or queries.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="tab-pane fade" id="upcoming" role="tabpanel" aria-labelledby="upcoming-tab">
                            <div className="accordion faq-wrapper" id="accordionExampleTwo">
                                <div className="card">
                                    <div className="card-header" id="ExtwoHeadingOne">
                                        <h2 className="mb-0">
                                            <button className="btn-link" type="button" data-toggle="collapse" data-target="#ExtwoCollapseOne"
                                                aria-expanded="true" aria-controls="ExtwoCollapseOne">
                                                <span className="count">1.</span> Frequently asked questions forum is often used ?
                                            </button>
                                        </h2>
                                    </div>
                                    <div id="ExtwoCollapseOne" className="collapse show" aria-labelledby="ExtwoHeadingOne" data-parent="#accordionExampleTwo">
                                        <div className="card-body">
                                            Making beauty especally relating complon especi common questions tend to recur, for example through
                                            posts or queries.
                                        </div>
                                    </div>
                                </div>
                                <div className="card">
                                    <div className="card-header" id="ExtwoHeadingTwo">
                                        <h2 className="mb-0">
                                            <button className="btn-link collapsed" type="button" data-toggle="collapse" data-target="#ExtwoCollapseTwo"
                                                aria-expanded="false" aria-controls="ExtwoCollapseTwo">
                                                <span className="count">2.</span> Business is shared to clarify questions ?
                                            </button>
                                        </h2>
                                    </div>
                                    <div id="ExtwoCollapseTwo" className="collapse" aria-labelledby="ExtwoHeadingTwo" data-parent="#accordionExampleTwo">
                                        <div className="card-body">
                                            Making beauty especally relating complon especi common questions tend to recur, for example through
                                            posts or queries.
                                        </div>
                                    </div>
                                </div>
                                <div className="card">
                                    <div className="card-header" id="ExtwoHeadingThree">
                                        <h2 className="mb-0">
                                            <button className="btn-link collapsed" type="button" data-toggle="collapse" data-target="#ExtwoCollapseThree"
                                                aria-expanded="false" aria-controls="ExtwoCollapseThree">
                                                <span className="count">3.</span> Making beauty especally relating complon especi ?
                                            </button>
                                        </h2>
                                    </div>
                                    <div id="ExtwoCollapseThree" className="collapse" aria-labelledby="ExtwoHeadingThree" data-parent="#accordionExampleTwo">
                                        <div className="card-body">
                                            Making beauty especally relating complon especi common questions tend to recur, for example through
                                            posts or queries.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="tab-pane fade" id="know" role="tabpanel" aria-labelledby="know-tab">
                            <div className="accordion faq-wrapper" id="accordionExampleThree">
                                <div className="card">
                                    <div className="card-header" id="ExthreeHeadingOne">
                                        <h2 className="mb-0">
                                            <button className="btn-link" type="button" data-toggle="collapse" data-target="#ExthreeCollapseOne"
                                                aria-expanded="true" aria-controls="ExthreeCollapseOne">
                                                <span className="count">1.</span> Frequently asked questions forum is often used ?
                                            </button>
                                        </h2>
                                    </div>
                                    <div id="ExthreeCollapseOne" className="collapse show" aria-labelledby="ExthreeHeadingOne" data-parent="#accordionExampleThree">
                                        <div className="card-body">
                                            Making beauty especally relating complon especi common questions tend to recur, for example through
                                            posts or queries.
                                        </div>
                                    </div>
                                </div>
                                <div className="card">
                                    <div className="card-header" id="ExthreeHeadingTwo">
                                        <h2 className="mb-0">
                                            <button className="btn-link collapsed" type="button" data-toggle="collapse" data-target="#ExthreeCollapseTwo"
                                                aria-expanded="false" aria-controls="ExthreeCollapseTwo">
                                                <span className="count">2.</span> Business is shared to clarify questions ?
                                            </button>
                                        </h2>
                                    </div>
                                    <div id="ExthreeCollapseTwo" className="collapse" aria-labelledby="ExthreeHeadingTwo" data-parent="#accordionExampleThree">
                                        <div className="card-body">
                                            Making beauty especally relating complon especi common questions tend to recur, for example through
                                            posts or queries.
                                        </div>
                                    </div>
                                </div>
                                <div className="card">
                                    <div className="card-header" id="ExthreeHeadingThree">
                                        <h2 className="mb-0">
                                            <button className="btn-link collapsed" type="button" data-toggle="collapse" data-target="#ExthreeCollapseThree"
                                                aria-expanded="false" aria-controls="ExthreeCollapseThree">
                                                <span className="count">3.</span> Making beauty especally relating complon especi ?
                                            </button>
                                        </h2>
                                    </div>
                                    <div id="ExthreeCollapseThree" className="collapse" aria-labelledby="ExthreeHeadingThree" data-parent="#accordionExampleThree">
                                        <div className="card-body">
                                            Making beauty especally relating complon especi common questions tend to recur, for example through
                                            posts or queries.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


</main>
    </>
  )
}

export default OurServies