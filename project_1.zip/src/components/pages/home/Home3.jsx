import React from 'react'
import {NavLink} from 'react-router-dom'
import { Homedata } from '../../assets/json/layout/Homedata'

import bg1 from '../../assets/img/slider/h3_banner_bg.png'
import bg3 from '../../assets/img/images/cons_testi_shape01.png'
import bg4 from '../../assets/img/images/cons_testi_shape02.png'
import img7 from '../../assets/img/slider/h3_banner_shape01.png'
import BusinessArea from '../../layout/footer/BusinessArea'
import Card from '../../layout/home/Card'

function Home3() {
  return (
    <>
        <main>

<section className="banner-area consulting-banner">
    <div className="slider-active">
        <div className="single-slider">
            <div className="container">
                <div className="row align-items-center">
                    <div className="col-lg-6 order-0 order-lg-2">
                        <div className="cons-banner-img">
{
    Homedata.map((data)=>{
        return(
            data.Consulting.map((data)=>{
                return(
                    data.carousel.map((data)=>{
                        return(
                                <img src={data.img}  alt="" className={data.className}/>
                        )
                    })
                )
            })
        )
    })
}
                        </div>
                    </div>
                    <div className="col-lg-6">
                        <div className="banner-content">
                            <div className="slider-caption">
                                <div className="inner-layer">
                                    <span className="sub-title" data-animation="reveal-text" data-delay="1s"><span style={{animationDelay: "1s"}}></span>tax Experts</span>
                                </div>
                            </div>
                            <div className="slider-caption">
                                <div className="inner-layer">
                                    <h2 className="title" data-animation="reveal-text" data-delay="2s"><span style={{animationDelay: "2s"}}></span>Business Consulting
                                    & Tax Experts</h2>
                                </div>
                            </div>
                            <div className="slider-caption">
                                <div className="inner-layer">
                                    <p data-animation="fade-in-up" data-delay="3s">Making for beauty especially of the relating to complexion
                                    especially of the face cosmetic.</p>
                                </div>
                            </div>
                            <div className="banner-btn" data-animation="fade-in-up" data-delay="3.5s">
                                <NavLink to={'/Contacts'} className="btn">Contact Us <span></span></NavLink>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div className="cons-banner-top-shape" style={{ backgroundImage: `url(${bg1})` }} ></div>
    <div className="cons-banner-top-shape2"><img src={img7} alt="" className="rotateme"/></div>
</section>

<Card/>

<section className="cons-services-area">
    <div className="container">
        <div className="">
            <div className="row justify-content-center">
                <div className="col-xl-7 col-lg-9">
                    <div className="kb-section-title text-center mb-55">
                        <h2 className="title">Services that we provide<span>.</span></h2>
                        <p>Making for beauty especially of the relating to complexion especially of the face cosmetic.</p>
                    </div>
                </div>
            </div>
            <div className="row justify-content-center">
                <div className="col-lg-4 col-md-6 col-sm-9">
                    <div className="cons-services-item mb-30">
                        <div className="cons-services-icon">
                            <i className="flaticon-support"></i>
                        </div>
                        <div className="cons-services-content">
                            <h5 className="title">Working Process</h5>
                            <p>Making for beauty especially the relating to complexion</p>
                        </div>
                    </div>
                </div>
                <div className="col-lg-4 col-md-6 col-sm-9">
                    <div className="cons-services-item mb-30">
                        <div className="cons-services-icon">
                            <i className="flaticon-online-service"></i>
                        </div>
                        <div className="cons-services-content">
                            <h5 className="title">Expert Auditing</h5>
                            <p>Making for beauty especially the relating to complexion</p>
                        </div>
                    </div>
                </div>
                <div className="col-lg-4 col-md-6 col-sm-9">
                    <div className="cons-services-item mb-30">
                        <div className="cons-services-icon">
                            <i className="flaticon-clutch-disc"></i>
                        </div>
                        <div className="cons-services-content">
                            <h5 className="title">Product Features</h5>
                            <p>Making for beauty especially the relating to complexion</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<BusinessArea/>

<section className="testimonial-area">
    <div className="container">
        <div className="row justify-content-center">
            <div className="col-xl-6 col-lg-8">
                <div className="kb-section-title text-center mb-55">
                    <h2 className="title">Our Customers Reviews<span>.</span></h2>
                    <p>Making for beauty especially of the relating to complexion especially of the face cosmetic.</p>
                </div>
            </div>
        </div>
        <div className="">
            <div className="testimonial-active">
                {
               Homedata.map((data)=>{
                return(
                    data.Consulting.map((data)=>{
                        return(
                            data.Reviews.map((data)=>{
                                return(
                                    <div className="testimonial-item">
                                <div className="row">
                                    <div className="col-lg-4">
                                        <div className="cons-testi-img">
                                            <img src={data.img}  alt=""/>
                                        </div>
                                    </div>
                                    <div className="col-lg-8">
                                        <div className="cons-testi-content-wrap">
                                            <div className="cons-testi-quote"><i className={data.icon}></i></div>
                                            <div className="cons-testi-content">
                                                <h4 className="title">{data.title}t</h4>
                                                <p>{data.info}</p>
                                                <div className="cons-testi-avatar">
                                                    <h5>{data.name}</h5>
                                                    <span>{data.work}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                )
                            })
                        )
                    })
                )
               })
                }
            </div>
            <div className="testimonial-slider-nav"></div>
            <div className="testimonial-img-wrap">
                <ul>
                    {
                        Homedata.map((data)=>{
                            return(
                                data.Consulting.map((data)=>{
                                    return(
                                        data.popup_img.map((data)=>{
                                            return(
                                                <li><img src={data.img}  alt=""/></li>
                                                )
                                        })
                                    )
                                })
                            )
                        })
                    }
                  
                </ul>
            </div>
        </div>
    </div>
    <div className="testi-top-shape" style={{ backgroundImage: `url(${bg3})` }} ></div>
    <div className="testi-bottom-shape" style={{ backgroundImage: `url(${bg4})` }}></div>
</section>

<div className="cons-brand-area pt-100 pb-100">
    <div className="container">
        <div className="">
            <div className="row cons-brand-active">
               
                    {
                        Homedata.map((data)=>{
                            return(
                                data.Consulting.map((data)=>{
                                    return(
                                        data.logo_list.map((data)=>{
                                            return(
                                                <div className="col-12">
                                                <div className="cons-brand-item">
                                                    <img src={data.img}  alt="img"/>
                                                </div>
                                            </div>
                                            )
                                        })
                                    )
                                })
                            )
                        })
                    }
                   
            </div>
        </div>
    </div>
</div>

<div className="cons-gallery-area">
    <div className="container">
        <div className="">
            <div className="row cos-gallery-active">
                {
                    Homedata.map((data)=>{
                        return(
                            data.Consulting.map((data)=>{
                                return(
                                    data.gallery.map((data)=>{
                                        return(
                                            <div className={data.type==='large'? "col-lg-6 grid-item":"col-lg-3 col-md-6 grid-item"}>
                                              <div className="cons-gallery-item">
                                                <a href={data.icon} className="popup-image"><img src={data.img} alt=""/></a>
                                                </div>
                                            </div>
                                        )
                                    })
                                )
                            })
                        )
                    })
                }
                
            </div>
        </div>
    </div>
</div>

<section className="customer-services">
    <div className="container">
        <div className="">
            <div className="row justify-content-center">
                <div className="col-xl-7 col-lg-9">
                    <div className="kb-section-title text-center mb-55">
                        <h2 className="title">Customer Service Platform<span>.</span></h2>
                        <p>Making for beauty especially of the relating to complexion especially of the face cosmetic.</p>
                    </div>
                </div>
            </div>
            <div className="customer-services-wrap">
                <div className="row no-gutters">
                    {
                        Homedata.map((data)=>{
                            return(
                                data.Consulting.map((data)=>{
                                    return(
                                        data.Service_Platform.map((data)=>{
                                            return(
                                                <div className="col-md-6">
                                        <div className="customer-services-item">
                                            <div className="customer-services-top">
                                                <div className="icon"><i className={data.icon}></i></div>
                                                <h4 className="title">{data.title}</h4>
                                            </div>
                                            <div className="customer-services-content">
                                                <p>{data.info}</p>
                                            </div>
                                        </div>
                                    </div>
                                            )
                                        })
                                    )
                                })
                            )
                        })
                    }
                </div>
            </div>
        </div>
    </div>
</section>


</main>
    </>
  )
}

export default Home3