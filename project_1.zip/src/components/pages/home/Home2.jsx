import React from 'react'
import {Link, NavLink} from 'react-router-dom'
import { Homedata } from '../../assets/json/layout/Homedata'

import bg2 from '../../assets/img/bg/team_bg.jpg'
import bg3 from '../../assets/img/bg/blog_bg.jpg'
import img1 from '../../assets/img/slider/banner_two_shape.png'
import img2 from '../../assets/img/slider/banner_two_img.png'
import TeamArea from '../../layout/TeamArea'
import BusinessArea from '../../layout/footer/BusinessArea'
import Card from '../../layout/home/Card'

function Home2() {
  return (
    <>
 <main>


<section className="software-banner-area banner-bg fix">
    <div className="container">
        <div className="soft-banner-wrap">
            <div className="software-banner-shape">
                <img src= {img1} className="alltuchtopdown" alt=""/>
            </div>
            <div className="software-banner-img">
                <img src= {img2} alt=""/>
            </div>
            <div className="row justify-content-end">
                <div className="col-lg-6">
                    <div className="banner-content">
                        <div className="slider-caption">
                            <div className="inner-layer">
                                <span className="sub-title wow slideInRight" data-wow-delay=".2s">software</span>
                            </div>
                        </div>
                        <div className="slider-caption">
                            <div className="inner-layer">
                                <h2 className="title wow slideInRight" data-wow-delay=".4s">Grow Your Business Online Today</h2>
                            </div>
                        </div>
                        <div className="slider-caption">
                            <div className="inner-layer">
                                <p className="wow slideInRight" data-wow-delay=".6s">Making for beauty especially of the relating to complexion especially of the face cosmetic.</p>
                            </div>
                        </div>
                        <div className="banner-btn wow slideInRight" data-wow-delay=".8s">
                            <NavLink to={'/Contacts'} className="btn">contact us<span></span></NavLink>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<Card/>

<section className="soft-services-area">
    <div className="container-fluid">
        <div className="">
            <div className="row align-items-end mb-50">
                <div className="col-md-7">
                    <div className="section-title-two">
                        <h5 className="sub-title">Services</h5>
                        <h2 className="title">That We Provide<span>.</span></h2>
                    </div>
                </div>
                <div className="col-md-5">
                    <div className="soft-title-link">
                        <NavLink to={'/OurServies'}>Browse All Services <i className="fas fa-long-arrow-alt-right"></i></NavLink>
                    </div>
                </div>
            </div>
            <div className="row soft-services-wrap justify-content-center">
{
    Homedata.map((data)=>{
        return(
            data.Services.map((data)=>{
                return(
                    <div className="col">
                            <div className="soft-services-item">
                                <div className="soft-services-icon">
                                    <img src= {data.img}  alt=""/>
                                </div>
                                <div className="soft-services-content">
                                    <h6><NavLink to={data.path}> {data.system}</NavLink></h6>
                                    <NavLink to={data.path} className="soft-services-link"><i className={data.icon}></i></NavLink>
                                </div>
                            </div>
                        </div>
                )
            })
        )
    })
}
            </div>
        </div>
    </div>
</section>

<BusinessArea/>

<section className="delivering-value-area pt-110 pb-70">
    <div className="container">
        <div className="">
            <div className="row justify-content-center">
                <div className="col-xl-6 col-lg-8">
                    <div className="kb-section-title text-center mb-55">
                        <h2 className="title">Delivering Value Customers.</h2>
                        <p>Get the latest Services and breaking news from Worald around the globe news</p>
                    </div>
                </div>
            </div>
            <div className="row justify-content-center">
{
   Homedata.map((data)=>{
    return(
        data.Delivering.map((data)=>{
            return(
                <div className="col-xl-4 col-lg-5 col-md-6 col-sm-10">
                <div className="delivering-value-item">
                    <div className="dv-thumb">
                        <NavLink to={data.path}><img src= {data.img}  alt=""/></NavLink>
                    </div>
                    <div className="dv-content-wrap">
                        <div className="icon"><i className={data.icon1}></i></div>
                        <div className="content">
                            <h4 className="title"><NavLink to={data.path}>{data.title}</NavLink></h4>
                            <p>{data.containt}</p>
                            <NavLink to={data.path}>Read more <i className={data.icon2}></i></NavLink>
                        </div>
                    </div>
                </div>
            </div>
            )
        })
    )
   })
}
            </div>
        </div>
    </div>
</section>

<section className="team-area team-bg" style={{ backgroundImage: `url(${bg2})` }} >
   <TeamArea/>
</section>



<section className="blog-area blog-bg" style={{ backgroundImage: `url(${bg3})` }} >
    <div className="container">
        <div className="">
            <div className="row justify-content-center">
                <div className="col-xl-6 col-lg-8">
                    <div className="kb-section-title text-center mb-55">
                        <h2 className="title">Latest News Update<span>.</span></h2>
                        <p>Get the latest Services and breaking news from Worald around the globe news</p>
                    </div>
                </div>
            </div>
            <div className="row justify-content-center">
                {
                   Homedata.map((data)=>{
                    return(
                        data.News.map((data)=>{
                            return(
                                <div className="col-lg-4 col-md-6 col-sm-9">
                        <div className="blog-post-item mb-30 wow fadeInUp" data-wow-delay=".2s">
                            <div className="blog-post-thumb">
                                <NavLink to={data.path}><img src= {data.Image}  alt=""/></NavLink>
                            </div>
                            <div className="blog-post-content">
                                <div className="blog-post-meta">
                                    <ul>
                                        <li><i className={data.icon1}></i> {data.date}</li>
                                        <li><i className={data.icon2}></i><Link to={'#'}>{data.comment}</Link></li>
                                    </ul>
                                </div>
                                <h5 className="title"><NavLink to={data.path}>{data.title}</NavLink></h5>
                                <NavLink to={data.path} className="read-more">{data.button}<i className={data.icon3}></i></NavLink>
                            </div>
                        </div>
                    </div>
                            )
                        })
                    )
                   })
                }
            </div>
        </div>
    </div>
</section>


</main>
    </>
  )
}

export default Home2