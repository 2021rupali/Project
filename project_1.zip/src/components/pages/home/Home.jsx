import React from "react";
import { NavLink} from 'react-router-dom'
import { AllinOne } from "../../assets/json/layout/AllinOne";

import img21 from '../../assets/img/images/features_shape01.png'
import img22 from '../../assets/img/images/features_shape02.png'
import bg1 from '../../assets/img/bg/feedback_bg.jpg'
import img26 from '../../assets/img/images/trial_shape01.png'
import img27 from '../../assets/img/images/trial_shape02.png'
import FeedbackArea from "../../layout/FeedbackArea";
import ServiceArea from "../../layout/ServiceArea";
import SupportArea from "../../layout/SupportArea";



function Home() {
  return (
    <>
      <section className="banner-area banner-bg">
        <div className="slider-active">
          <div className="single-slider">
            <div className="container">
              <div className="row align-items-center">
                <div className="col-lg-6 order-0 order-lg-2">
                  <div className="banner-img">
                   {
                    AllinOne.map((data)=>{
                      return(
                        data.Banner.map((data)=>{
                          return(<img
                            src={data.img}
                            className={data.className}
                            alt=""
                          />
                           
                          )
                        })
                      )
                    })
                   }
                  </div>
                </div>
                <div className="col-lg-6">
                  <div className="banner-content">
                    <div className="slider-caption">
                      <div className="inner-layer">
                        <span
                          className="sub-title"
                          data-animation="reveal-text"
                          data-delay="1s"
                        >
                          <span style={{animationDelay: "1s"}}></span>CodeFirst</span>
                      </div>
                    </div>
                    <div className="slider-caption">
                      <div className="inner-layer">
                        <h2
                          className="title"
                          data-animation="reveal-text"
                          data-delay="2s"
                        >
                          <span ></span>Improve Your Technical Skills With CodeFirst !</h2>
                      </div>
                    </div>
                    <div className="slider-caption">
                      <div className="inner-layer">
                        <p data-animation="fade-in-up" data-delay="3s">
                        “Every business must become digital, doesn’t matter which industry you belong to.”
                        </p>
                      </div>
                    </div>
                    <div
                      className="banner-btn"
                      data-animation="fade-in-up"
                      data-delay="3.5s"
                    >
                      <NavLink to={'/Contacts'} className="btn">
                        <i className="far fa-user"></i> Register Here
                        <span></span>
                      </NavLink>
                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="brand-area">
        <div className="container">
          <div className="">
            <div className="row">
              <div className="col-12">
                <div className="brand-wrapper">
                  <h2 className="title">
                  <span>200+</span>  Students Are Enrolled<span> 100%</span> Satisfied Rate.
                  </h2>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <section className="features-area pt-120 pb-90">
        <div className="container">
          <div className="">
            <div className="row align-items-center">
              <div className="col-xl-7">
                <div className="row features-item-wrap">
{
  AllinOne.map((data)=>{
    return(
      data.Features.map((data)=>{
        return(
          <div className="col-md-6">
                        <div className="features-item-box mb-30">
                          <div className="features-item-icon">
                            <img src={data.img_link} alt="" />
                          </div>
                          <div className="features-item-content">
                            <h4>{data.title}</h4>
                            <p>{data.content}</p>
                          </div>
                        </div>
                      </div>
        )
      })
    )
  })
}
                  <div className="features-top-shape">
                    <img src={img21} alt="" />
                  </div>
                </div>
              </div>
              <div className="col-xl-5">
                <div className="features-content-wrap">
                  <div className="features-title">
                    <span className="sub-title">articles</span>
                    <h2 className="title">Practices Online Training With Live Coding</h2>
                  </div>
                 
                  
                  <div className="features-list">
                    <ul>
                      <li>
                        <div className="icon">
                          <i className="fas fa-check"></i>
                        </div>
                        <div className="content">
                          <h5>We have record of 100% placement Support from last one year</h5>
                         
                        </div>
                        
                      </li>
                    </ul>
                  </div>
                  <div className="features-list">
                    <ul>
                      <li>
                        <div className="icon">
                          <i className="fas fa-check"></i>
                        </div>
                        <div className="content">
                          <h5>Resume Uploading on Different Jobs Sites with recent</h5>
                        
                        </div>
                        
                      </li>
                    </ul>
                  </div>
                  <div className="features-list">
                    <ul>
                      <li>
                        <div className="icon">
                          <i className="fas fa-check"></i>
                        </div>
                        <div className="content">
                          <h5>Provide 100% interview Questions set A skill sets</h5>
                        
                        </div>
                        
                      </li>
                    </ul>
                  </div>
                  <div className="features-list">
                    <ul>
                      <li>
                        <div className="icon">
                          <i className="fas fa-check"></i>
                        </div>
                        <div className="content">
                          <h4>Daily Mock Interviews A Weekly Presentation </h4>
                        
                        </div>
                        
                      </li>
                    </ul>
                  </div>
                  <div className="features-list">
                    <ul>
                      <li>
                        <div className="icon">
                          <i className="fas fa-check"></i>
                        </div>
                        <div className="content">
                          <h5>HR DISCUSSION & Soft Skills</h5>
                        
                        </div>
                        
                      </li>
                    </ul>
                  </div>

                
                  <NavLink to={'/OurServies'} className="btn">
                    <i className="far fa-paper-plane"></i> Discover all Features{" "}
                    <span></span>
                  </NavLink>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="features-right-shape">
          <img src={img22} alt="" />
        </div>
      </section>

      <section
        className="customer-feedback-area"
        style={{ backgroundImage: `url(${bg1})` }}
      >
        <FeedbackArea/>
      </section>

     <ServiceArea/>

      <section className="trial-area">
        <div className="container">
          <div className="">
            <div className="row">
              <div className="col-12">
                <div className="kb-trial-wrap">
                  <h2 className="title">
                    Are you ready to get your business grossing
                  </h2>
                  <div className="kb-trial-form">
                    <form action="#">
                      <input type="email" placeholder="Email address" />
                      <button className="btn">
                        14-day Free Trial <span></span>
                      </button>
                    </form>
                  </div>
                  <img
                    src={img26}
                    alt=""
                    className="trial-shape top-shape wow fadeInDownBig"
                    data-wow-delay=".3s"
                  />
                  <img
                    src={img27}
                    alt=""
                    className="trial-shape bottom-shape wow fadeInUpBig"
                    data-wow-delay=".3s"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <SupportArea/>
    </>
  );
}

export default Home;
